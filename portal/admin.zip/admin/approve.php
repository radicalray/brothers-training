<?php
include_once '../../includes/db_connect.php';
include_once '../../includes/functions.php';

sec_session_start();

$id = $_POST['id'];
$approved = $_POST['approved'];
$not_approved = $_POST['not_approved'];
$comments = $_POST['comments'];

approve($mysqli, $id, $approved, $not_approved, $comments);

header('Location: view.php?id='.$id);

?>
