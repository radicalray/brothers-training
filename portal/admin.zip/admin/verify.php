<?php
include_once '../../includes/db_connect.php';
include_once '../../includes/functions.php';

sec_session_start();

$id = $_POST['id'];
$payment = $_POST['payment'];

verify_payment($mysqli, $id, $payment);

header('Location: view.php?id='.$id);

?>
