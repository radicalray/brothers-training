<html>
<head>
<title>Getting your AuthUserFile root location</title>
</head>
<body>
<?php echo “<h1>Your website root location is “;
echo $_SERVER[‘DOCUMENT_ROOT’];
echo “ </h1>”;
?>
</body>
</html> 
